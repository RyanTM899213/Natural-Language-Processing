to compile and run this code on your machine, go to terminal and cd into the 
directory where the code is located and type "javac *.java"

make sure the java compiler is installed on your testing machine

to run the program, in terminal type "java Tester"

now see the results of the running code

I've made comments and side notes in the .java file itself, so open java
file with a simple text editor to view.
